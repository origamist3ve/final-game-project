using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Charged : MonoBehaviour
{
    public float charge;
}
